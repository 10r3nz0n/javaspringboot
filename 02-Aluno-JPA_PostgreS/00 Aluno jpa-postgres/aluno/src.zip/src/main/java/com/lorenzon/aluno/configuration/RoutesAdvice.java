package com.lorenzon.aluno.configuration;

import org.springframework.stereotype.Component;

@Component("routes")
public class RoutesAdvice {

    public static final String WEB_ALUNO = "/web/aluno";
    public static final String NOVO = "/novo";
    public static final String SALVAR = "/salvar";
    public static final String LISTAR = "/listar";

    public String webAluno() {
        return WEB_ALUNO;
    }

    public String novo() {
        return NOVO;
    }

    public String salvar() {
        return SALVAR;
    }

    public String listar() {
        return LISTAR;
    }
}
