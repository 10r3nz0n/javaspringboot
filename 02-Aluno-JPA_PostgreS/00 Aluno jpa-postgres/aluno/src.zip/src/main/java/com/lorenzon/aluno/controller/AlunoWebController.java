package com.lorenzon.aluno.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.lorenzon.aluno.configuration.Routes; //aqui ficam as rotas
import com.lorenzon.aluno.configuration.RoutesAdvice;
import com.lorenzon.aluno.dto.AlunoForm;
import com.lorenzon.aluno.model.Aluno;
import com.lorenzon.aluno.service.AlunoWebService;

import lombok.AllArgsConstructor;

@Controller
@AllArgsConstructor
@RequestMapping(RoutesAdvice.WEB_ALUNO)

public class AlunoWebController {

    @Autowired
    private final AlunoWebService alunoWebService;

    @GetMapping(RoutesAdvice.NOVO)
    public String novo(Model model) {
        model.addAttribute("alunoForm", new AlunoForm());
        return "aluno-form";
    }

    @PostMapping(RoutesAdvice.SALVAR)
    public String salvar(@ModelAttribute("alunoForm") AlunoForm alunoForm, Model model) {
        try {
            alunoWebService.cadastrar(alunoForm);
            return "redirect:/web/aluno/listar";
        } catch (IllegalArgumentException e) {
            model.addAttribute("erro", e.getMessage());
            return "aluno-form";
        }
    }

    @GetMapping(RoutesAdvice.LISTAR)
    public String lista(Model model) {
        List<Aluno> alunos = alunoWebService.listar();
        model.addAttribute("alunos", alunos);
        return "aluno-lista";
    }

}